package com.gdsc.recyclr.screens.shop

data class ShopItem(
    val imageId:Int,
    val title:String,
    val price:Int
)
