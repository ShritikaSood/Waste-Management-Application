package com.gdsc.recyclr

/*Store: C:\Users\kwize\.android\debug.keystore
Alias: AndroidDebugKey
MD5: 92:0D:72:15:F2:79:7F:E8:5A:57:48:A2:B6:B8:F1:3A
SHA1: 47:48:1D:B6:20:4A:12:C2:FA:C4:13:96:9E:06:56:9E:C7:50:26:DE
SHA-256: 25:4E:1F:44:37:29:06:10:0E:31:25:73:CA:55:E9:9D:7B:D1:94:1D:BC:98:77:B9:F2:76:44:E0:3F:65:2A:A4
Valid until: Wednesday, March 19, 2053*/

/*Store: /home/honneur/.android/debug.keystore
Alias: AndroidDebugKey
MD5: 4F:2A:34:57:08:B3:0B:A7:38:E1:45:4A:F7:E0:FB:DE
SHA1: EB:BB:56:6B:41:E3:A2:5B:E5:59:B2:A7:62:01:52:8A:40:95:64:1C
SHA-256: CD:5A:2B:54:0E:BC:77:4E:C5:C5:02:39:29:3F:E6:59:16:67:32:65:E2:0B:C8:D3:49:7B:1E:A4:F5:36:53:3C
Valid until: Sunday, 6 October 2052
*/